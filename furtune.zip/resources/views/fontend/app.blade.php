
 @include('fontend.head')
 @include('fontend.header')
 @include('fontend.menu')
 @include('fontend.slider')
 @yield('content')
 @include('fontend.footer')
