<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class facility extends Model
{
    //
}
