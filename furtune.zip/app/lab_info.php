<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class lab_info extends Model
{
    //
}
