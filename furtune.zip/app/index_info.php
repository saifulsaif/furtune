<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class index_info extends Model
{
    //
}
