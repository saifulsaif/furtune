<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class sub_menu_list extends Model
{
    //
}
