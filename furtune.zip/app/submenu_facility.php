<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class submenu_facility extends Model
{
    //
}
