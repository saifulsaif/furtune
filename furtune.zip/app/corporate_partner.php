<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class corporate_partner extends Model
{
    //
}
