<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class service_info extends Model
{
    //
}
