<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class health_package extends Model
{
    //
}
