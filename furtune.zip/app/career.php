<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class career extends Model
{
    //
}
