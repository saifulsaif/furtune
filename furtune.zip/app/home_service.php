<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class home_service extends Model
{
    //
}
