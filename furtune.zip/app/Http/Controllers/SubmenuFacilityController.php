<?php

namespace App\Http\Controllers;

use App\submenu_facility;
use Illuminate\Http\Request;

class SubmenuFacilityController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\submenu_facility  $submenu_facility
     * @return \Illuminate\Http\Response
     */
    public function show(submenu_facility $submenu_facility)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\submenu_facility  $submenu_facility
     * @return \Illuminate\Http\Response
     */
    public function edit(submenu_facility $submenu_facility)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\submenu_facility  $submenu_facility
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, submenu_facility $submenu_facility)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\submenu_facility  $submenu_facility
     * @return \Illuminate\Http\Response
     */
    public function destroy(submenu_facility $submenu_facility)
    {
        //
    }
}
