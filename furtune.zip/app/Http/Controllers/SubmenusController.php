<?php

namespace App\Http\Controllers;

use App\submenus;
use Illuminate\Http\Request;

class SubmenusController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\submenus  $submenus
     * @return \Illuminate\Http\Response
     */
    public function show(submenus $submenus)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\submenus  $submenus
     * @return \Illuminate\Http\Response
     */
    public function edit(submenus $submenus)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\submenus  $submenus
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, submenus $submenus)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\submenus  $submenus
     * @return \Illuminate\Http\Response
     */
    public function destroy(submenus $submenus)
    {
        //
    }
}
