<?php $__env->startSection('content'); ?>
    <style media="screen">
        .form-group{
            margin:10px;
        }
    </style>
<div class="panel-body" style="padding:20px 0px 0px 0px">
    <form class="form-horizontal" method="post" id="form" enctype="multipart/form-data" action="<?php echo e(CRUDBooster::mainpath('edit')); ?>">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
        <input type="hidden" name="return_url" value="<?php echo e(url('admin/doctors')); ?>">
        <input type="hidden" name="ref_mainpath" value="<?php echo e(url('admin/doctors')); ?>">
        <input type="hidden" name="ref_parameter" value="return_url=<?php echo e(url('admin/doctors&amp;parent_id=&amp;parent_field=')); ?>">
        <input type="hidden" name="doctor_id" value="<?php echo e($doctor->id); ?>">
        <div class="box-body" id="parent-form-area">

        <div class="form-group header-group-0 " id="form-group-center" style="">
        <label class="control-label col-sm-2">
        Center
        <span class="text-danger" title="This field is required">*</span>
        </label>

        <div class="col-sm-10">
        <input type="text" title="Center" required="" maxlength="255" class="form-control" name="center" id="center" value="<?php echo e($doctor->center); ?>">

        <div class="text-danger"></div>
        <p class="help-block"></p>

        </div>
        </div>
        <div class="form-group header-group-0 " id="form-group-department" style="">
            <label class="control-label col-sm-2">
            Department
            <span class="text-danger" title="This field is required">*</span>
            </label>

            <div class="col-sm-10">
            <input type="text" title="Department" required="" maxlength="255" class="form-control" name="department" id="department" value="<?php echo e($doctor->department); ?>">

            <div class="text-danger"></div>
            <p class="help-block"></p>

            </div>
        </div>
        <div class="form-group header-group-0 " id="form-group-doctor_name" style="">
            <label class="control-label col-sm-2">
                Doctor Name
                <span class="text-danger" title="This field is required">*</span>
            </label>

            <div class="col-sm-10">
                <input type="text" title="Doctor Name" required="" maxlength="255" class="form-control" name="doctor_name" id="doctor_name" value="<?php echo e($doctor->doctor_name); ?>">

                <div class="text-danger"></div>
                <p class="help-block"></p>

            </div>
        </div>
        <div class="form-group header-group-0 " id="form-group-doctor_degree" style="">
            <label class="control-label col-sm-2">
                Doctor Degree
                <span class="text-danger" title="This field is required">*</span>
            </label>

            <div class="col-sm-10">
                <input type="text" title="Doctor Degree" required="" maxlength="255" class="form-control" name="doctor_degree" id="doctor_degree" value="<?php echo e($doctor->doctor_degree); ?>">

                <div class="text-danger"></div>
                <p class="help-block"></p>

            </div>
        </div>
            <div class="form-group header-group-0 " id="form-group-status" style="">
                <label class="control-label col-sm-2">Status
                    <span class="text-danger" title="This field is required">*</span>
                </label>

                

                <div class="col-sm-10">
                    <input type="checkbox" title="Status" <?php if($doctor->status == 1): ?> checked <?php endif; ?> required="" name="status" id="status">
                    <div class="text-danger"></div>
                    <p class="help-block"></p>
                </div>
            </div>

            
            
                <div class="col-md-6">
                    <div class="form-group header-group-0 " id="form-group-department" style="">
                        <label class="control-label col-sm-2">
                        Start days
                        <span class="text-danger" title="This field is required">*</span>
                        </label>

                        <div class="col-sm-10">
                        <select class="form-control" name="start_days" id="exampleFormControlSelect1">
                          <option disabled>Select Day</option>
                          <option <?php if($doctor->times->start_days == 'Saturday'): ?> selected <?php endif; ?> value="Saturday">Saturday</option>
                          <option <?php if($doctor->times->start_days == 'Sunday'): ?> selected <?php endif; ?> value="Sunday">Sunday</option>
                          <option <?php if($doctor->times->start_days == 'Monday'): ?> selected <?php endif; ?> value="Monday">Monday</option>
                          <option <?php if($doctor->times->start_days == 'Tuesday'): ?> selected <?php endif; ?> value="Tuesday">Tuesday</option>
                          <option <?php if($doctor->times->start_days == 'Wednesday'): ?> selected <?php endif; ?> value="Wednesday">Wednesday</option>
                          <option <?php if($doctor->times->start_days == 'Thursday'): ?> selected <?php endif; ?> value="Thursday">Thursday</option>
                          <option <?php if($doctor->times->start_days == 'Friday'): ?> selected <?php endif; ?> value="Friday">Friday</option>
                        </select>
                        <div class="text-danger"></div>
                        <p class="help-block"></p>

                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group header-group-0 " id="form-group-start_time" style="">
                        <label class="control-label col-sm-2">
                        Time
                        <span class="text-danger" title="This field is required">*</span>
                        </label>

                        <div class="col-sm-10">
                        <input type="text" title="Department" required="" maxlength="255" class="form-control" name="start_time" id="start_time" value="<?php echo e($doctor->times->strat_time); ?>">

                        <div class="text-danger"></div>
                        <p class="help-block"></p>

                        </div>
                    </div>
                </div>

            
            
                <div class="col-md-6">
                    <div class="form-group header-group-0 " id="form-group-start_time" style="">
                        <label class="control-label col-sm-2">
                        End Day
                        <span class="text-danger" title="This field is required">*</span>
                        </label>

                        <div class="col-sm-10">
                            <select class="form-control" name="end_days" id="exampleFormControlSelect1">
                              <option disabled>Select Day</option>
                              <option <?php if($doctor->times->end_days == 'Saturday'): ?> selected <?php endif; ?> value="Saturday">Saturday</option>
                              <option <?php if($doctor->times->end_days == 'Sunday'): ?> selected <?php endif; ?> value="Sunday">Sunday</option>
                              <option <?php if($doctor->times->end_days == 'Monday'): ?> selected <?php endif; ?> value="Monday">Monday</option>
                              <option <?php if($doctor->times->end_days == 'Tuesday'): ?> selected <?php endif; ?> value="Tuesday">Tuesday</option>
                              <option <?php if($doctor->times->end_days == 'Wednesday'): ?> selected <?php endif; ?> value="Wednesday">Wednesday</option>
                              <option <?php if($doctor->times->end_days == 'Thursday'): ?> selected <?php endif; ?> value="Thursday">Thursday</option>
                              <option <?php if($doctor->times->end_days == 'Friday'): ?> selected <?php endif; ?> value="Friday">Friday</option>
                            </select>
                        <div class="text-danger"></div>
                        <p class="help-block"></p>

                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group header-group-0 " id="form-group-end_time" style="">
                        <label class="control-label col-sm-2">
                        Time
                        <span class="text-danger" title="This field is required">*</span>
                        </label>

                        <div class="col-sm-10">
                        <input type="text" title="Department" required="" maxlength="255" class="form-control" name="end_time" id="end_time" value="<?php echo e($doctor->times->end_time); ?>">

                        <div class="text-danger"></div>
                        <p class="help-block"></p>

                        </div>
                    </div>
                </div>
            
            
                <div class="col-md-4">
                    <div class="form-group header-group-0 " id="form-group-start_time" style="">
                        <label class="control-label col-sm-2">
                        Special Day
                        <span class="text-danger" title="This field is required">*</span>
                        </label>

                        <div class="col-sm-10">
                            <select class="form-control" name="special_days" id="exampleFormControlSelect1">
                                <option <?php if($doctor->times->special_days == 'Saturday'): ?> selected <?php endif; ?> value="Saturday">Saturday</option>
                                <option <?php if($doctor->times->special_days == 'Sunday'): ?> selected <?php endif; ?> value="Sunday">Sunday</option>
                                <option <?php if($doctor->times->special_days == 'Monday'): ?> selected <?php endif; ?> value="Monday">Monday</option>
                                <option <?php if($doctor->times->special_days == 'Tuesday'): ?> selected <?php endif; ?> value="Tuesday">Tuesday</option>
                                <option <?php if($doctor->times->special_days == 'Wednesday'): ?> selected <?php endif; ?> value="Wednesday">Wednesday</option>
                                <option <?php if($doctor->times->special_days == 'Thursday'): ?> selected <?php endif; ?> value="Thursday">Thursday</option>
                                <option <?php if($doctor->times->special_days == 'Friday'): ?> selected <?php endif; ?> value="Friday">Friday</option>
                            </select>
                        <div class="text-danger"></div>
                        <p class="help-block"></p>

                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group header-group-0 " id="form-group-end_time" style="">
                        <label class="control-label col-sm-2">
                        Start Time
                        <span class="text-danger" title="This field is required">*</span>
                        </label>

                        <div class="col-sm-10">
                        <input type="text" title="Department" required="" maxlength="255" class="form-control" name="special_start_time" id="end_time" value="<?php echo e($doctor->times->special_strat_time); ?>">

                        <div class="text-danger"></div>
                        <p class="help-block"></p>

                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group header-group-0 " id="form-group-end_time" style="">
                        <label class="control-label col-sm-2">
                        End Time
                        <span class="text-danger" title="This field is required">*</span>
                        </label>

                        <div class="col-sm-10">
                        <input type="text" title="Department" required="" maxlength="255" class="form-control" name="special_end_time" id="end_time" value="<?php echo e($doctor->times->special_end_time); ?>">

                        <div class="text-danger"></div>
                        <p class="help-block"></p>

                        </div>
                    </div>
                </div>
            

            <div class="col-md-12">
                <div class="form-group header-group-0 " id="form-group-end_time" style="">
                    <label class="control-label col-sm-2">
                    Opnion
                    <span class="text-danger" title="This field is required">*</span>
                    </label>

                    <div class="col-sm-10">
                    <textarea class="form-control" name="opinion" id="exampleFormControlTextarea1" rows="3"><?php echo e($doctor->times->opinion); ?></textarea>

                    <div class="text-danger"></div>
                    <p class="help-block"></p>

                    </div>
                </div>
            </div>
        </div><!-- /.box-body -->

        <div class="box-footer" style="background: #F5F5F5">

        <div class="form-group">
            <label class="control-label col-sm-2"></label>
            <div class="col-sm-10">
                <a href="<?php echo url('admin/doctors'); ?>" class="btn btn-default"><i class="fa fa-chevron-circle-left"></i> Back</a>

                <input type="submit" name="submit" value="Save" class="btn btn-success">

            </div>
        </div>




        </div><!-- /.box-footer-->

    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('crudbooster::admin_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\furtune\resources\views/backend/doctors/editDoctor.blade.php ENDPATH**/ ?>