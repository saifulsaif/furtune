



<!--  Banner Start   -->




<script>
    function banner()
    {
        window.location.href='https://surakshanet.com/about-us/company-profile';
    }
</script>

<div class="banner_div" style="max-height:450px;">
    <div class="owl-carousel owl-theme" id="banner_slider">
        <?php if(!empty(getValueByTBName('slider'))): ?>
            <?php $__currentLoopData = getValueByTBName('slider'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="item">
                 <a href="#"> <img src="<?php echo e(asset($slider->image_link)); ?>" style="max-height:450px;" alt="Banner"></a>
              </div>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
</div>







<!--  Banner End   -->
<?php /**PATH C:\xampp\htdocs\furtune\resources\views/fontend/slider.blade.php ENDPATH**/ ?>