# Time Form Input Type
Showing a timepicker

### Code Sample
```php
$this->form[] = ['label'=>'Start Time','name'=>'start_time','type'=>'time'];
```
It will produce the value H:i:s

## What's Next
- [Form Input Type: upload](./form-upload.md)

## Table Of Contents
- [Back To Index](./index.md)