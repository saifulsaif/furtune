# Text Form Input Type
Showing an input text

### Code Sample
```php
$this->form[] = ['label'=>'Full Name','name'=>'full_name','type'=>'text'];
```

## What's Next
- [Form Input Type: textarea](./form-textarea.md)

## Table Of Contents
- [Back To Index](./index.md)