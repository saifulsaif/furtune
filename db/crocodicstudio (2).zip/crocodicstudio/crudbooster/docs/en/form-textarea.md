# Textarea Form Input Type
Showing a textarea input type

### Code Sample
```php
$this->form[] = ['label'=>'Description','name'=>'description','type'=>'textarea'];
```

## What's Next
- [Form Input Type: time](./form-time.md)

## Table Of Contents
- [Back To Index](./index.md)