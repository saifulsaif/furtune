# Email Form Type
Set input type html as email

### Code Sample
```php
$this->form[] = ['label'=>'Email','name'=>'email','type'=>'email'];
```

## What's Next
- [Form Input Type: filemanager](./form-filemanager.md)

## Table Of Contents
- [Back To Index](./index.md)