# Date Form Type
Showing datepicker in the input type

### Code Sample
```php
$this->form[] = ['label'=>'Date Of Birth','name'=>'date_birth','type'=>'date'];
```

## What's Next
- [Form Input Type: datetime](./form-datetime.md)

## Table Of Contents
- [Back To Index](./index.md)