# Password Form Type
Showing a password input type

### Code Sample
```php
$this->form[] = ['label'=>'Password','name'=>'password','type'=>'password'];
```
It will auto make a `hash` once the data saved

## What's Next
- [Form Input Type: radio](./form-radio.md)

## Table Of Contents
- [Back To Index](./index.md)